want to buy this project Contact Info-  +91-9964716807
# Online_Inventory_shop
Online shop with admin and supplier 
User Side Home Page 
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(470).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(471).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(472).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(473).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(474).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(475).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(476).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(477).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(478).png)


Admin Page
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(479).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(480).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(481).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(482).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(483).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(484).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(485).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(486).png)

Suplier side Home page
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(487).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(488).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(489).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(490).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(491).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(492).png)

Discussion Page 
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(493).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(494).png)
![Image of user](https://github.com/nikhilkeshava/Online_Inventory_shop/blob/master/screenshots/Screenshot%20(495).png)





For More Info 
Contact +91-9964716807

